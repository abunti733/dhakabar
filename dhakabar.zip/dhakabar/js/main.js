$(document).ready(function(){

	var num = 100; //number of pixels before modifying styles

	$(window).bind('scroll', function () {

		if ($(window).scrollTop() > num) {

			$('#menu').addClass('fixed');

		} else {

			$('#menu').removeClass('fixed');

		}

	});

})


// animate button one start
$( ".button_su_inner" ).mouseenter(function(e) {
   var parentOffset = $(this).offset(); 
  
   var relX = e.pageX - parentOffset.left;
   var relY = e.pageY - parentOffset.top;
   $(this).prev(".su_button_circle").css({"left": relX, "top": relY });
   $(this).prev(".su_button_circle").removeClass("desplode-circle");
   $(this).prev(".su_button_circle").addClass("explode-circle");

});

$( ".button_su_inner" ).mouseleave(function(e) {

   var parentOffset = $(this).offset(); 

   var relX = e.pageX - parentOffset.left;
   var relY = e.pageY - parentOffset.top;
   $(this).prev(".su_button_circle").css({"left": relX, "top": relY });
   $(this).prev(".su_button_circle").removeClass("explode-circle");
   $(this).prev(".su_button_circle").addClass("desplode-circle");

});
//animate button one end
